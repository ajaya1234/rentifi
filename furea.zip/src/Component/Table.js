import React from 'react'
import Header from './Header'
import Footerone from './Footerone'
function Table() {
  return (
    <div>
      <Header/>
      <p>Table</p>
      <Footerone/>
    </div>
  )
}

export default Table
