import React from 'react'
import Header from './Header'
import Footerone from './Footerone'

function Chair() {
  return (
    <div>
        <Header/>
        <p>Charis</p>
       <Footerone/>
    </div>
  )
}

export default Chair
