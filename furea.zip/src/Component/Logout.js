// import { Navigate } from 'react-router-dom';


// function Logout  ()

//     // localStorage.removeItem("user_arr");
//     // setUserArr(null);



// {
//     localStorage.removeItem('token')
//     localStorage.removeItem('_id')
    
//     localStorage.removeItem('name')
//     localStorage.removeItem('email')	  
//     localStorage.removeItem('password')
//     localStorage.removeItem('phone')
//     localStorage.removeItem('role')
//     localStorage.setItem('info')  
    
    

    
//     return(
//         <div>

//             <Navigate to='/login'/>Logout
//         </div>
//     )
// }


// export default Logout


