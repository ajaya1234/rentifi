import React from 'react'
// import Header from './Header'
//import Headerone from './Headerone'
import Header from './Header'
import { Link } from 'react-router-dom'
import Headerone from './Headerone'
function Profile() {
  
  return (
    <section className="categories__section color-scheme-2 section--padding pt-0">
<Headerone/>
      {/* <img src="assets/img/icon/referral.cb4ca7e.svg" style="float: right;"> */}
      <div className="container">
        <div className="categories__inner d-flex align-items-center">
          <div className="categories__content">
            <h2 className="categories__content--title">Hey John jarvis,</h2>
            <p className="categories__content--desc">Do you want to change your profession?</p>
            <ul className="categories__product d-flex">
              {/* <a class="categories__product--icons" href="shop.html"><svg class="categories__product--icons__svg" xmlns="assets/img/icon/working-profession.svg" width="28.626" height="26.234" viewBox="0 0 28.626 26.234">
                                      <path id="armchair" d="M30.577,18.414a3.375,3.375,0,0,0-2.886-2.8,4.027,4.027,0,0,0-.415-.019V14.155A7.163,7.163,0,0,0,20.121,7H12.49a7.163,7.163,0,0,0-7.155,7.155V15.59a4.027,4.027,0,0,0-.415.019,3.375,3.375,0,0,0-2.886,2.8A3.315,3.315,0,0,0,4.381,22.12v6.344A1.435,1.435,0,0,0,5.812,29.9v2.862a.477.477,0,0,0,.477.477H7.72a.477.477,0,0,0,.458-.348L9.031,29.9H23.579l.854,2.991a.477.477,0,0,0,.458.348h1.431a.477.477,0,0,0,.477-.477V29.9a1.435,1.435,0,0,0,1.431-1.431V22.12a3.315,3.315,0,0,0,2.347-3.706ZM6.289,14.155a6.207,6.207,0,0,1,6.2-6.2h7.632a6.207,6.207,0,0,1,6.2,6.2v1.574a3.327,3.327,0,0,0-2.385,3.2v1.517a1.431,1.431,0,0,0-.477-.086H9.151a1.431,1.431,0,0,0-.477.086V18.925a3.327,3.327,0,0,0-2.385-3.2Zm17.648,7.632v2.385H8.674V21.786a.477.477,0,0,1,.477-.477H23.46A.477.477,0,0,1,23.937,21.786ZM7.362,32.28h-.6V29.9H8.039Zm18.483,0h-.6L24.572,29.9h1.274Zm1.827-11.009a.481.481,0,0,0-.4.472v6.721a.477.477,0,0,1-.477.477H5.812a.477.477,0,0,1-.477-.477V21.744a.481.481,0,0,0-.4-.472,2.382,2.382,0,0,1,.1-4.713,2.119,2.119,0,0,1,.3-.019h0a2.351,2.351,0,0,1,1.574.6,2.388,2.388,0,0,1,.806,1.784v5.724a.477.477,0,0,0,.477.477H24.414a.477.477,0,0,0,.477-.477V18.925a2.388,2.388,0,0,1,.806-1.784,2.352,2.352,0,0,1,1.879-.582,2.394,2.394,0,0,1,2.056,1.994v0A2.373,2.373,0,0,1,27.672,21.271Z" transform="translate(-1.992 -7)" fill="currentColor"/>
                                      </svg>
                                      <span class="visually-hidden">Categories</span> 
                                  </a>   */}
              <li className="categories__product--list">
                <Link className="categories__product--icons" to="/working">                               
                  <img src="assets/img/icon/working-profession.svg" alt='' className="img-size" />
                </Link>
                <p style={{padding: '12px 0px 0px 0px'}}>Working<br />  
                  Professional</p>
              </li>
              <li className="categories__product--list">
                <Link className="categories__product--icons" to="/working">                               
                  <img src="assets/img/icon/self-employed.svg"  alt=''/>
                </Link>  
                <p style={{padding: '12px 0px 0px 0px'}}>Self Employe</p>
              </li>
              <li className="categories__product--list">
                <Link className="categories__product--icons" to="/working">                               
                  <img src="assets/img/icon/freelancer.svg" alt='' />
                </Link> 
                <p style={{padding: '12px 0px 0px 0px'}}>Freelancer</p> 
              </li>
              <li className="categories__product--list">
                <Link className="categories__product--icons" alt='' to="/student">                               
                  <img src="assets/img/icon/student.svg" alt='' />
                </Link>  
                <p style={{padding: '12px 0px 0px 0px'}}>Student</p>
              </li>
              {/* <li class="categories__product--list">
                                  <a class="categories__product--icons" href="shop.html">
                                      <svg class="categories__product--icons__svg" xmlns="http://www.w3.org/2000/svg" width="22.8" height="34.994" viewBox="0 0 22.8 34.994">
                                          <path d="M111.033,14.455l-.952-5.825a.512.512,0,1,0-1.011.165l.849,5.2a47.363,47.363,0,0,0-13.506-.652.512.512,0,0,0,.093,1.02,46.314,46.314,0,0,1,13.318.657,1.559,1.559,0,0,1,1.246,1.528V18.16a1.561,1.561,0,0,1-1.559,1.559H91.879A1.561,1.561,0,0,1,90.32,18.16V16.576a1.559,1.559,0,0,1,1.274-1.533c.909-.169,1.836-.317,2.752-.439a.512.512,0,0,0-.136-1.015c-.934.125-1.877.275-2.8.447h0l1.44-8.854a4.933,4.933,0,0,1,4.888-4.157h5.857a4.934,4.934,0,0,1,4.887,4.153l.237,1.448a.512.512,0,1,0,1.011-.165l-.237-1.448A5.976,5.976,0,0,0,103.592,0H97.735a5.976,5.976,0,0,0-5.9,5.017l-1.549,9.524a2.584,2.584,0,0,0-.991,2.035V18.16a2.586,2.586,0,0,0,2.583,2.583h.387l-2,13.16a.948.948,0,0,0,.938,1.091h.509a.943.943,0,0,0,.908-.676L95.8,23.733l1.168-.723h7.448l1.168.723.516,1.718a.512.512,0,1,0,.981-.295l-1.326-4.413h2.331L110.1,33.969h-.364l-2.02-6.723a.512.512,0,1,0-.981.295l2.036,6.777a.943.943,0,0,0,.908.676h.509a.948.948,0,0,0,.938-1.091l-2-13.16h.387A2.586,2.586,0,0,0,112.1,18.16V16.544a2.59,2.59,0,0,0-1.062-2.089ZM91.659,33.97H91.3L93.3,20.743h2.331Zm13.483-11.717-.194-.12a.979.979,0,0,0-.516-.147H96.959a.98.98,0,0,0-.516.147l-.194.12.454-1.51h7.987Z" transform="translate(-89.296)" fill="currentColor"/>
                                      </svg>  
                                      <span class="visually-hidden">Categories 2</span> 
                                  </a>                                 
                              </li>
                              <li class="categories__product--list">
                                  <a class="categories__product--icons" href="shop.html">
                                      <svg class="categories__product--icons__svg" xmlns="http://www.w3.org/2000/svg" width="29.069" height="19.531" viewBox="0 0 29.069 19.531">
                                          <g id="bed" transform="translate(0 -84)">
                                            <g id="Group_194" data-name="Group 194" transform="translate(0 84)">
                                              <path id="Path_120" data-name="Path 120" d="M24.981,89.9h-.454V86.271A2.274,2.274,0,0,0,22.256,84H6.813a2.274,2.274,0,0,0-2.271,2.271V89.9H4.088A4.093,4.093,0,0,0,0,93.993v6.359H.908v3.179H3.179v-3.179H25.89v3.179h2.271v-3.179h.908V93.993A4.093,4.093,0,0,0,24.981,89.9ZM5.451,86.271a1.363,1.363,0,0,1,1.363-1.363H22.256a1.363,1.363,0,0,1,1.363,1.363V89.9H22.256V88.088a1.363,1.363,0,0,0-1.363-1.363H16.806a1.363,1.363,0,0,0-1.363,1.363V89.9H13.626V88.088a1.363,1.363,0,0,0-1.363-1.363H8.176a1.363,1.363,0,0,0-1.363,1.363V89.9H5.451Zm15.9,1.817V89.9h-5V88.088a.454.454,0,0,1,.454-.454h4.088A.454.454,0,0,1,21.348,88.088Zm-8.63,0V89.9h-5V88.088a.454.454,0,0,1,.454-.454h4.088A.454.454,0,0,1,12.718,88.088ZM2.271,102.623H1.817v-2.271h.454Zm24.981,0H26.8v-2.271h.454Zm.908-3.179H.908V97.172H28.161Zm0-3.179H.908V93.993a3.183,3.183,0,0,1,3.179-3.179H24.981a3.183,3.183,0,0,1,3.179,3.179Z" transform="translate(0 -84)" fill="currentColor"/>
                                            </g>
                                          </g>
                                      </svg> 
                                      <span class="visually-hidden">Categories 3</span> 
                                  </a>                                 
                              </li>
                              <li class="categories__product--list">
                                  <a class="categories__product--icons" href="shop.html">
                                      <svg class="categories__product--icons__svg" xmlns="http://www.w3.org/2000/svg" width="21.44" height="30.211" viewBox="0 0 21.44 30.211">
                                          <path d="M100.953,24.568h-.588L96.555,8.376A.487.487,0,0,0,96.08,8H85.36a.487.487,0,0,0-.474.376l-3.81,16.192h-.588a.487.487,0,0,0-.487.487V27a.487.487,0,0,0,.487.487h8.284v3.24l-3.645,4.557H83.472a.487.487,0,0,0-.469.355l-.548,1.949a.487.487,0,0,0,.469.619H98.517a.487.487,0,0,0,.473-.605L98.5,35.657a.487.487,0,0,0-.473-.369H96.314l-3.645-4.557v-3.24h5.36V29.44a.517.517,0,0,0,.007.082,1.462,1.462,0,1,0,.96,0A.514.514,0,0,0,99,29.44V27.491h1.949A.487.487,0,0,0,101.44,27V25.055A.487.487,0,0,0,100.953,24.568ZM85.746,8.975h9.948l3.669,15.593H82.077Zm11.9,27.288.244.975H83.567l.274-.975Zm-2.583-.975H86.374l3.265-4.081a.489.489,0,0,0,.107-.3V27.491h1.949V30.9a.489.489,0,0,0,.107.3ZM99,30.9a.487.487,0,1,1-.487-.487A.487.487,0,0,1,99,30.9Zm1.462-4.386H80.975v-.975h19.491Z" transform="translate(-80 -8)" fill="currentColor"/>
                                      </svg> 
                                      <span class="visually-hidden">Categories 4</span> 
                                  </a>                                  
                              </li>
                              <li class="categories__product--list">
                                  <a class="categories__product--icons" href="shop.html">
                                      <svg class="categories__product--icons__svg" xmlns="http://www.w3.org/2000/svg" width="40.031" height="21.953" viewBox="0 0 40.031 21.953">
                                          <path d="M48.013,123.072l-.646-2.583a.646.646,0,0,0-.626-.489H9.292a.646.646,0,0,0-.626.489l-.646,2.583a.646.646,0,0,0,.626.8h1.937v17.433a.646.646,0,0,0,.646.646h1.937a.646.646,0,0,0,.646-.646v-9.039H42.221v9.039a.646.646,0,0,0,.646.646H44.8a.646.646,0,0,0,.646-.646V123.874h1.937a.646.646,0,0,0,.626-.8Zm-35.492,17.59h-.646V123.874h.646Zm29.7-9.685H13.812v-7.1H42.221Zm1.937,9.685h-.646V123.874h.646ZM9.474,122.583l.323-1.291h36.44l.323,1.291Z" transform="translate(-8.001 -120)" fill="currentColor"/>
                                      </svg> 
                                      <span class="visually-hidden">Categories 5</span> 
                                  </a>                                                                   
                              </li>
                              <li class="categories__product--list">
                                  <a class="categories__product--icons" href="shop.html">
                                      <svg class="categories__product--icons__svg" xmlns="http://www.w3.org/2000/svg" width="34.974" height="15.625" viewBox="0 0 34.974 15.625">
                                          <path d="M33.765,127.935a2.384,2.384,0,0,0-.352,0h0l-2.848,0a2.726,2.726,0,0,0-1.551.409,7.715,7.715,0,0,0-.15-1.16,1.234,1.234,0,0,0-1.2-.957H7.308a1.234,1.234,0,0,0-1.2.957,7.715,7.715,0,0,0-.151,1.16,2.726,2.726,0,0,0-1.551-.409l-2.848,0h0a2.382,2.382,0,0,0-.352,0A1.325,1.325,0,0,0,0,129.248V137.5a2.144,2.144,0,0,0,2.142,2.142h.617v1.523a.69.69,0,0,0,1.179.488l2.011-2.011H29.025l2.011,2.011a.69.69,0,0,0,1.179-.488v-1.523h.617a2.144,2.144,0,0,0,2.142-2.142v-8.248A1.325,1.325,0,0,0,33.765,127.935Zm-3.2.536h1.482a2.392,2.392,0,0,0-.663.855l-.9,1.956a4.936,4.936,0,0,0,.013,4.148A13.984,13.984,0,0,0,27.443,134a4.375,4.375,0,0,1,.353-2.491l.9-1.956A1.81,1.81,0,0,1,30.566,128.471ZM7.308,126.762H27.666a.694.694,0,0,1,.675.537,8.38,8.38,0,0,1,.156,1.536,2.657,2.657,0,0,0-.289.489l-.9,1.956a4.906,4.906,0,0,0-.427,2.542,14.01,14.01,0,0,0-2.448-.464,75.243,75.243,0,0,0-13.9,0,14,14,0,0,0-2.446.463,4.907,4.907,0,0,0-.427-2.542l-.9-1.956a2.657,2.657,0,0,0-.289-.49,8.367,8.367,0,0,1,.156-1.536A.694.694,0,0,1,7.308,126.762Zm-2.9,1.708a1.81,1.81,0,0,1,1.871,1.078l.9,1.956A4.373,4.373,0,0,1,7.53,134a13.986,13.986,0,0,0-3.055,1.434,4.936,4.936,0,0,0,.013-4.148l-.9-1.956a2.391,2.391,0,0,0-.663-.855Zm-.849,12.8a.154.154,0,0,1-.263-.109v-1.523H5.19Zm28.12-.109a.154.154,0,0,1-.263.109l-1.632-1.632h1.894v1.523Zm2.759-3.665a1.605,1.605,0,0,1-1.605,1.605H2.142A1.605,1.605,0,0,1,.536,137.5v-8.248a.786.786,0,0,1,.716-.778A1.871,1.871,0,0,1,3.1,129.549l.9,1.956a4.4,4.4,0,0,1-.955,5.014l.371.387h0a7.135,7.135,0,0,1,.931-.757,13.452,13.452,0,0,1,6.241-2.256,74.686,74.686,0,0,1,13.794,0,13.454,13.454,0,0,1,6.242,2.256,7.136,7.136,0,0,1,.928.753l0,0,.371-.387a4.4,4.4,0,0,1-.955-5.014l.9-1.956a1.872,1.872,0,0,1,1.849-1.079.786.786,0,0,1,.716.778V137.5Z" transform="translate(0 -126.226)" fill="currentColor"/>
                                      </svg> 
                                      <span class="visually-hidden">Categories 6</span> 
                                  </a>                                 
                              </li>
                              <li class="categories__product--list">
                                  <a class="categories__product--icons" href="shop.html">
                                      <svg class="categories__product--icons__svg" xmlns="http://www.w3.org/2000/svg" width="20.041" height="29.584" viewBox="0 0 20.041 29.584">
                                          <g id="wardrobe" transform="translate(-88 -8)">
                                            <path id="Path_121" data-name="Path 121" d="M107.564,8H88.477A.477.477,0,0,0,88,8.477V9.909a.477.477,0,0,0,.477.477h.477V34.721a.477.477,0,0,0,.477.477v1.909a.477.477,0,0,0,.477.477h16.224a.477.477,0,0,0,.477-.477V35.2a.477.477,0,0,0,.477-.477V10.386h.477a.477.477,0,0,0,.477-.477V8.477A.477.477,0,0,0,107.564,8Zm-1.909,28.63H90.386V35.2h15.269ZM89.909,34.244V10.386h7.635V34.244Zm16.224,0H98.5V10.386h7.635Zm.954-24.813H88.954V8.954h18.132Z" transform="translate(0 0)" fill="currentColor"/>
                                            <path id="Path_122" data-name="Path 122" d="M224.477,224a.477.477,0,0,0-.477.477v2.863a.477.477,0,1,0,.954,0v-2.863A.477.477,0,0,0,224.477,224Z" transform="translate(-127.888 -203.116)" fill="currentColor"/>
                                            <path id="Path_123" data-name="Path 123" d="M272.477,227.817a.477.477,0,0,0,.477-.477v-2.863a.477.477,0,1,0-.954,0v2.863A.477.477,0,0,0,272.477,227.817Z" transform="translate(-173.025 -203.116)" fill="currentColor"/>
                                          </g>
                                      </svg> 
                                      <span class="visually-hidden">Categories 7</span>  
                                  </a>                               
                              </li>
                              <li class="categories__product--list">
                                  <a class="categories__product--icons" href="shop.html">
                                      <svg class="categories__product--icons__svg" xmlns="http://www.w3.org/2000/svg" width="21.158" height="35.443" viewBox="0 0 21.158 35.443">
                                          <g id="ceiling-lamp" transform="translate(-103.178)">
                                            <g id="Group_195" data-name="Group 195" transform="translate(103.178)">
                                              <path id="Path_124" data-name="Path 124" d="M119.792,240.4a.519.519,0,0,0-.519-.519H104.389a.173.173,0,0,1-.173-.173v-2.943a9.5,9.5,0,0,1,1.605-5.3.519.519,0,0,0-.863-.577,10.53,10.53,0,0,0-1.781,5.876v2.943a1.213,1.213,0,0,0,1.211,1.211h5.193a4.275,4.275,0,0,0,8.35,0h1.341A.519.519,0,0,0,119.792,240.4Zm-6.035,2.837a3.228,3.228,0,0,1-3.1-2.318h6.21A3.228,3.228,0,0,1,113.757,243.239Z" transform="translate(-103.178 -214.693)" fill="currentColor"/>
                                              <path id="Path_125" data-name="Path 125" d="M164.8,14.245h0a10.554,10.554,0,0,0-4.113-2.316V10.57a1.8,1.8,0,0,0-1.794-1.794H158.2V.519a.519.519,0,1,0-1.038,0V8.776h-.689a1.8,1.8,0,0,0-1.794,1.794v1.359a10.552,10.552,0,0,0-4.141,2.342.519.519,0,1,0,.7.766,9.541,9.541,0,0,1,12.857-.025h0a9.563,9.563,0,0,1,3.124,7.061v2.943a.173.173,0,0,1-.173.173h-1.429a.519.519,0,0,0,0,1.038h1.429a1.213,1.213,0,0,0,1.211-1.211V22.074A10.6,10.6,0,0,0,164.8,14.245Zm-5.151-2.568a10.664,10.664,0,0,0-3.928,0V10.57a.757.757,0,0,1,.756-.756h2.416a.757.757,0,0,1,.756.756Z" transform="translate(-147.107)" fill="currentColor"/>
                                              <path id="Path_126" data-name="Path 126" d="M249.019,451.955a.519.519,0,0,0-.519.519v3.118a.519.519,0,0,0,1.038,0v-3.118A.519.519,0,0,0,249.019,451.955Z" transform="translate(-238.44 -420.669)" fill="currentColor"/>
                                              <path id="Path_127" data-name="Path 127" d="M330.257,422.22a.519.519,0,0,0-.735.734l2.2,2.2a.519.519,0,0,0,.735-.734Z" transform="translate(-313.713 -392.85)" fill="currentColor"/>
                                              <path id="Path_128" data-name="Path 128" d="M138.164,422.22l-2.2,2.2a.519.519,0,0,0,.735.734l2.2-2.2a.519.519,0,0,0-.735-.734Z" transform="translate(-133.55 -392.85)" fill="currentColor"/>
                                            </g>
                                          </g>
                                      </svg>
                                      <span class="visually-hidden">Categories 8</span> 
                                  </a>                                 
                              </li> */}
            </ul>  
            <a className="categories__content--btn primary__btn btn__style2" href="shop.html">See All Categories</a>     
          </div>
          {/* <div class="categories__sidebar">
                          <div class="categories__sidebar--inner">
                              <div class="banner__items position__relative">
                                  <a class="banner__items--thumbnail " href="shop.html"><img class="banner__items--thumbnail__img" src="assets/img/banner/banner19.webp" alt="banner-img"></a>
                                  <div class="bideo__play">
                                      <a class="bideo__play--icon glightbox" href="https://vimeo.com/115041822" data-gallery="video">
                                          <svg id="play" xmlns="http://www.w3.org/2000/svg" width="46.302" height="46.302" viewBox="0 0 46.302 46.302">
                                              <g id="Group_193" data-name="Group 193" transform="translate(0 0)">
                                              <path id="Path_116" data-name="Path 116" d="M39.521,6.781a23.151,23.151,0,0,0-32.74,32.74,23.151,23.151,0,0,0,32.74-32.74ZM23.151,44.457A21.306,21.306,0,1,1,44.457,23.151,21.33,21.33,0,0,1,23.151,44.457Z" fill="currentColor"/>
                                              <g id="Group_188" data-name="Group 188" transform="translate(15.588 11.19)">
                                                  <g id="Group_187" data-name="Group 187">
                                                  <path id="Path_117" data-name="Path 117" d="M190.3,133.213l-13.256-8.964a3,3,0,0,0-4.674,2.482v17.929a2.994,2.994,0,0,0,4.674,2.481l13.256-8.964a3,3,0,0,0,0-4.963Zm-1.033,3.435-13.256,8.964a1.151,1.151,0,0,1-1.8-.953V126.73a1.134,1.134,0,0,1,.611-1.017,1.134,1.134,0,0,1,1.185.063l13.256,8.964a1.151,1.151,0,0,1,0,1.907Z" transform="translate(-172.366 -123.734)" fill="currentColor"/>
                                                  </g>
                                              </g>
                                              <g id="Group_190" data-name="Group 190" transform="translate(28.593 5.401)">
                                                  <g id="Group_189" data-name="Group 189">
                                                  <path id="Path_118" data-name="Path 118" d="M328.31,70.492a18.965,18.965,0,0,0-10.886-10.708.922.922,0,1,0-.653,1.725,17.117,17.117,0,0,1,9.825,9.664.922.922,0,1,0,1.714-.682Z" transform="translate(-316.174 -59.724)" fill="currentColor"/>
                                                  </g>
                                              </g>
                                              <g id="Group_192" data-name="Group 192" transform="translate(22.228 4.243)">
                                                  <g id="Group_191" data-name="Group 191">
                                                  <path id="Path_119" data-name="Path 119" d="M249.922,47.187a19.08,19.08,0,0,0-3.2-.27.922.922,0,0,0,0,1.845,17.245,17.245,0,0,1,2.889.243.922.922,0,1,0,.31-1.818Z" transform="translate(-245.801 -46.917)" fill="currentColor"/>
                                                  </g>
                                              </g>
                                              </g>
                                          </svg>
                                          <span class="visually-hidden">Play</span>
                                      </a> 
                                  </div>
                              </div>
                          </div> */}
        </div>
      </div>
    </section>
    
  )
}




export default Profile
