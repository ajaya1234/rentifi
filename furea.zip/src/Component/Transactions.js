
import React from 'react'
import Header from './Header';
import Footerone from './Footerone';

function Transactions() {
  return (
    <div>
<Header/>
<Footerone/>
    </div>
  )
}

export default Transactions;
