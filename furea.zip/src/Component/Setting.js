import React from 'react'
import Header from './Header'
import Headerone from './Headerone';
function Setting() {
  return (
    <div>
      <Headerone/>
    </div>
  )
}

export default Setting;