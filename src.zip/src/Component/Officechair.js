import React from 'react'
import Header from './Header'
import Footerone from './Footerone'
function Officechair() {
  return (
    <div>
      <Header/>
      <p>officechair</p>
      <Footerone/>
      </div>
  )
}

export default Officechair;
