import React from 'react'
import Header from './Header'
import Footerone from './Footerone'

function Dressingtable() {
  return (
    <div>
        <Header/>
      <p>Dressingtable</p>
    <Footerone/>
    </div>
  )
}

export default Dressingtable
