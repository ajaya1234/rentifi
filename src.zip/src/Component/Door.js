import React from 'react'
import Header from './Header'
import Footerone from './Footerone'
function Door() {
  return (
    <div>
      <Header/>
      <p>Door</p>
      <Footerone/>
    </div>
  )
}

export default Door
